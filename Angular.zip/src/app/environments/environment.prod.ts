export const environment = {
  production: false,
  cognito: {
    clientId: '17maovn490jgjo4sahig56bs9b',
    domain: 'us-east-2qhnriu1dn.auth.us-east-2.amazoncognito.com',
    redirectUri: 'https://yhj.grittonbelldev.com/auth-callback',
  },
};
